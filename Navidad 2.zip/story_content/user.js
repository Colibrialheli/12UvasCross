function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6dBHPvgnNHE":
        Script1();
        break;
      case "6efAPapAwXv":
        Script2();
        break;
      case "6r2PPbSUnrT":
        Script3();
        break;
      case "5UybbzxheRo":
        Script4();
        break;
      case "5uUpKdlEtVA":
        Script5();
        break;
      case "6LaUPeMQRQC":
        Script6();
        break;
      case "6po7r3xhYe3":
        Script7();
        break;
      case "5haQrAXSDyQ":
        Script8();
        break;
      case "5rk8g2j1g4O":
        Script9();
        break;
      case "6aXOu6VFsvq":
        Script10();
        break;
      case "6MEVlWIp5GO":
        Script11();
        break;
      case "5wVbUQ7aKDN":
        Script12();
        break;
      case "6JHwuXgNhcq":
        Script13();
        break;
      case "6QSvXgI2LRV":
        Script14();
        break;
      case "5hqSHn6YgyR":
        Script15();
        break;
      case "5gd7PKYchoD":
        Script16();
        break;
      case "697OyKYz3nq":
        Script17();
        break;
      case "5kBFpyAqFxd":
        Script18();
        break;
      case "66GRkKPrIwE":
        Script19();
        break;
      case "5a4LfxEOPyy":
        Script20();
        break;
      case "5XRDw1EfuCd":
        Script21();
        break;
      case "5jrTrfU8MNb":
        Script22();
        break;
      case "6l0jZhp3SKk":
        Script23();
        break;
      case "619wO0Pa1qJ":
        Script24();
        break;
      case "6RvaOteCIwd":
        Script25();
        break;
      case "5oRH1gub520":
        Script26();
        break;
      case "5gAH5a5wVUV":
        Script27();
        break;
      case "6hONKMXLoPH":
        Script28();
        break;
      case "5pVeTVFOymi":
        Script29();
        break;
      case "5Y9VphbgDZe":
        Script30();
        break;
      case "5eag9DqLqSu":
        Script31();
        break;
      case "5fIXmQMs0za":
        Script32();
        break;
      case "6hHgveh2U1s":
        Script33();
        break;
      case "64EkyEFcTLg":
        Script34();
        break;
      case "6Bx3XqlhPma":
        Script35();
        break;
      case "5WU5249K124":
        Script36();
        break;
      case "5kNtFp82O3v":
        Script37();
        break;
      case "6iMjjjdaCYE":
        Script38();
        break;
      case "5fbCmy2QAtS":
        Script39();
        break;
      case "5n8hCFZt5DU":
        Script40();
        break;
      case "6mTWFUcqIj4":
        Script41();
        break;
      case "6lxfFb7cj3E":
        Script42();
        break;
      case "62FtnpX2WDs":
        Script43();
        break;
      case "5bLIJfulPyM":
        Script44();
        break;
      case "61QgZQdsSXG":
        Script45();
        break;
      case "5cHJftdyMY0":
        Script46();
        break;
      case "5kUb33CVumn":
        Script47();
        break;
      case "60ku5bTkM9g":
        Script48();
        break;
      case "6eiHcXLodZv":
        Script49();
        break;
      case "5w6OWBmp5hb":
        Script50();
        break;
      case "6gzlcAZEj0C":
        Script51();
        break;
      case "5yjwCmLifhT":
        Script52();
        break;
      case "5h4FWi3TdrZ":
        Script53();
        break;
      case "64VN4FAWizg":
        Script54();
        break;
      case "6baqHZxF15r":
        Script55();
        break;
      case "631APGsBXKX":
        Script56();
        break;
  }
}

function Script1()
{
  document.querySelector("#bgSong").play();
}

function Script2()
{
  document.querySelector("#bgSong").pause();
}

function Script3()
{
  function crearReproductor() {   
reproductor = `<audio id="bgSong" src="story_content/external_files/bg.mp3" loop></audio>`;

   if  (!document.querySelector("#bgSong"))    { 
        console.log("No existe reproductor, ahora a crearlo");
        document.querySelector("body").insertAdjacentHTML('beforeend', reproductor);
        document.querySelector("#bgSong").volume = 0.2;
    }
}
crearReproductor();
}

function Script4()
{
  document.querySelector("#bgSong").play();
}

function Script5()
{
  document.querySelector("#bgSong").pause();
}

function Script6()
{
  document.querySelector("#bgSong").play();
}

function Script7()
{
  document.querySelector("#bgSong").pause();
}

function Script8()
{
  function crearReproductor() {   
reproductor = `<audio id="bgSong" src="story_content/external_files/bg.mp3" loop></audio>`;

   if  (!document.querySelector("#bgSong"))    { 
        console.log("No existe reproductor, ahora a crearlo");
        document.querySelector("body").insertAdjacentHTML('beforeend', reproductor);
        document.querySelector("#bgSong").volume = 0.2;
    }
}
crearReproductor();
}

function Script9()
{
  document.querySelector("#bgSong").play();
}

function Script10()
{
  document.querySelector("#bgSong").pause();
}

function Script11()
{
  document.querySelector("#bgSong").play();
}

function Script12()
{
  document.querySelector("#bgSong").pause();
}

function Script13()
{
  function crearReproductor() {   
reproductor = `<audio id="bgSong" src="story_content/external_files/bg.mp3" loop></audio>`;

   if  (!document.querySelector("#bgSong"))    { 
        console.log("No existe reproductor, ahora a crearlo");
        document.querySelector("body").insertAdjacentHTML('beforeend', reproductor);
        document.querySelector("#bgSong").volume = 0.2;
    }
}
crearReproductor();
}

function Script14()
{
  document.querySelector("#bgSong").play();
}

function Script15()
{
  document.querySelector("#bgSong").pause();
}

function Script16()
{
  document.querySelector("#bgSong").play();
}

function Script17()
{
  document.querySelector("#bgSong").pause();
}

function Script18()
{
  function crearReproductor() {   
reproductor = `<audio id="bgSong" src="story_content/external_files/bg.mp3" loop></audio>`;

   if  (!document.querySelector("#bgSong"))    { 
        console.log("No existe reproductor, ahora a crearlo");
        document.querySelector("body").insertAdjacentHTML('beforeend', reproductor);
        document.querySelector("#bgSong").volume = 0.2;
    }
}
crearReproductor();
}

function Script19()
{
  document.querySelector("#bgSong").play();
}

function Script20()
{
  document.querySelector("#bgSong").pause();
}

function Script21()
{
  document.querySelector("#bgSong").play();
}

function Script22()
{
  document.querySelector("#bgSong").pause();
}

function Script23()
{
  function crearReproductor() {   
reproductor = `<audio id="bgSong" src="story_content/external_files/bg.mp3" loop></audio>`;

   if  (!document.querySelector("#bgSong"))    { 
        console.log("No existe reproductor, ahora a crearlo");
        document.querySelector("body").insertAdjacentHTML('beforeend', reproductor);
        document.querySelector("#bgSong").volume = 0.2;
    }
}
crearReproductor();
}

function Script24()
{
  document.querySelector("#bgSong").play();
}

function Script25()
{
  document.querySelector("#bgSong").pause();
}

function Script26()
{
  document.querySelector("#bgSong").play();
}

function Script27()
{
  document.querySelector("#bgSong").pause();
}

function Script28()
{
  function crearReproductor() {   
reproductor = `<audio id="bgSong" src="story_content/external_files/bg.mp3" loop></audio>`;

   if  (!document.querySelector("#bgSong"))    { 
        console.log("No existe reproductor, ahora a crearlo");
        document.querySelector("body").insertAdjacentHTML('beforeend', reproductor);
        document.querySelector("#bgSong").volume = 0.2;
    }
}
crearReproductor();
}

function Script29()
{
  document.querySelector("#bgSong").play();
}

function Script30()
{
  document.querySelector("#bgSong").pause();
}

function Script31()
{
  document.querySelector("#bgSong").play();
}

function Script32()
{
  document.querySelector("#bgSong").pause();
}

function Script33()
{
  function crearReproductor() {   
reproductor = `<audio id="bgSong" src="story_content/external_files/bg.mp3" loop></audio>`;

   if  (!document.querySelector("#bgSong"))    { 
        console.log("No existe reproductor, ahora a crearlo");
        document.querySelector("body").insertAdjacentHTML('beforeend', reproductor);
        document.querySelector("#bgSong").volume = 0.2;
    }
}
crearReproductor();
}

function Script34()
{
  document.querySelector("#bgSong").play();
}

function Script35()
{
  document.querySelector("#bgSong").pause();
}

function Script36()
{
  document.querySelector("#bgSong").play();
}

function Script37()
{
  document.querySelector("#bgSong").pause();
}

function Script38()
{
  function crearReproductor() {   
reproductor = `<audio id="bgSong" src="story_content/external_files/bg.mp3" loop></audio>`;

   if  (!document.querySelector("#bgSong"))    { 
        console.log("No existe reproductor, ahora a crearlo");
        document.querySelector("body").insertAdjacentHTML('beforeend', reproductor);
        document.querySelector("#bgSong").volume = 0.2;
    }
}
crearReproductor();
}

function Script39()
{
  document.querySelector("#bgSong").play();
}

function Script40()
{
  document.querySelector("#bgSong").pause();
}

function Script41()
{
  document.querySelector("#bgSong").play();
}

function Script42()
{
  document.querySelector("#bgSong").pause();
}

function Script43()
{
  function crearReproductor() {   
reproductor = `<audio id="bgSong" src="story_content/external_files/bg.mp3" loop></audio>`;

   if  (!document.querySelector("#bgSong"))    { 
        console.log("No existe reproductor, ahora a crearlo");
        document.querySelector("body").insertAdjacentHTML('beforeend', reproductor);
        document.querySelector("#bgSong").volume = 0.2;
    }
}
crearReproductor();
}

function Script44()
{
  document.querySelector("#bgSong").play();
}

function Script45()
{
  document.querySelector("#bgSong").pause();
}

function Script46()
{
  document.querySelector("#bgSong").play();
}

function Script47()
{
  document.querySelector("#bgSong").pause();
}

function Script48()
{
  function crearReproductor() {   
reproductor = `<audio id="bgSong" src="story_content/external_files/bg.mp3" loop></audio>`;

   if  (!document.querySelector("#bgSong"))    { 
        console.log("No existe reproductor, ahora a crearlo");
        document.querySelector("body").insertAdjacentHTML('beforeend', reproductor);
        document.querySelector("#bgSong").volume = 0.2;
    }
}
crearReproductor();
}

function Script49()
{
  document.querySelector("#bgSong").play();
}

function Script50()
{
  document.querySelector("#bgSong").pause();
}

function Script51()
{
  document.querySelector("#bgSong").play();
}

function Script52()
{
  document.querySelector("#bgSong").pause();
}

function Script53()
{
  window.print();
}

function Script54()
{
  function crearReproductor() {   
reproductor = `<audio id="bgSong" src="story_content/external_files/bg.mp3" loop></audio>`;

   if  (!document.querySelector("#bgSong"))    { 
        console.log("No existe reproductor, ahora a crearlo");
        document.querySelector("body").insertAdjacentHTML('beforeend', reproductor);
        document.querySelector("#bgSong").volume = 0.2;
    }
}
crearReproductor();
}

function Script55()
{
  document.querySelector("#bgSong").play();
}

function Script56()
{
  document.querySelector("#bgSong").pause();
}

